#! /bin/bash

echo -n "Apple"
echo "Mango"
