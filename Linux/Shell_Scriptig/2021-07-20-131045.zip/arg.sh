#! /bin/bash

echo "The Number of arguments : $#"
echo " Script Name : $0"
echo " First Argurment : $1"
echo " Second Argurment : $2"
echo " Third Argurment : $3"
echo " Four Argurment : $4"
echo " Fifth  Argurment : $5"
echo " All arguments with *: $*"
echo " All arguments with @: $@"


