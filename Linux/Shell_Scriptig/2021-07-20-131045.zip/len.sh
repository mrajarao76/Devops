#! /bin/bash


len=$(echo -n "$1" | wc -c)
echo "The length of given string $1 :$len"


