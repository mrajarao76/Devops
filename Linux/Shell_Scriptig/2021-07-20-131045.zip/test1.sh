#! /bin/bash
IFS=" \t\n-"
echo " All arguments with *: $*"
echo " All arguments with @: $@"


