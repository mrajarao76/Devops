# Testing

Run tests with:

    $ bundle exec run spec

To run a single spec file only, run something like:

    $ bundle exec run spec SPECNAME

