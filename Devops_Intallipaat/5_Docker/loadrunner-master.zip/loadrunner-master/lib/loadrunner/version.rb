module Loadrunner
  VERSION = "0.4.4"
end