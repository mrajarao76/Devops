# ansible-code

This repository contains Exercises to understand the Ansible Automation.
