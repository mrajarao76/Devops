#!/bin/bash

touch remotefile.txt
