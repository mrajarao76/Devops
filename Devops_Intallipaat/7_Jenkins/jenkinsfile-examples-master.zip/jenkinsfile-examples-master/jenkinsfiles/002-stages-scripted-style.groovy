node {

  stage('Stage 1') {
    echo 'Stage 1'
  }

  stage('Stage 2') {
    echo 'Stage 2'
  }

}
